-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for penyewaan_futsal
CREATE DATABASE IF NOT EXISTS `penyewaan_futsal` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `penyewaan_futsal`;

-- Dumping structure for table penyewaan_futsal.cabang
CREATE TABLE IF NOT EXISTS `cabang` (
  `id_cabang` int NOT NULL AUTO_INCREMENT,
  `nama_cabang` varchar(30) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  PRIMARY KEY (`id_cabang`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.cabang: ~20 rows (approximately)
INSERT INTO `cabang` (`id_cabang`, `nama_cabang`, `alamat`, `telepon`, `email`) VALUES
	(1, 'Cabang Jakarta', 'Jl. Sudirman No.10, Jakarta', '0211234567', 'jakarta@cabang.com'),
	(2, 'Cabang Bandung', 'Jl. Pasteur No.5, Bandung', '0223456789', 'bandung@cabang.com'),
	(3, 'Cabang Surabaya', 'Jl. Basuki Rahmat No.20, Surabaya', '0315678901', 'surabaya@cabang.com'),
	(4, 'Cabang Medan', 'Jl. Gatot Subroto No.15, Medan', '0612345678', 'medan@cabang.com'),
	(5, 'Cabang Bali', 'Jl. Sunset Road No.8, Bali', '0361123456', 'bali@cabang.com'),
	(6, 'Cabang Semarang', 'Jl. Diponegoro No.12, Semarang', '0243456123', 'semarang@cabang.com'),
	(7, 'Cabang Makassar', 'Jl. Pettarani No.3, Makassar', '0411345678', 'makassar@cabang.com'),
	(8, 'Cabang Palembang', 'Jl. Demang Lebar Daun No.7, Palembang', '0711345678', 'palembang@cabang.com'),
	(9, 'Cabang Yogyakarta', 'Jl. Malioboro No.1, Yogyakarta', '0274123456', 'yogya@cabang.com'),
	(10, 'Cabang Balikpapan', 'Jl. MT Haryono No.9, Balikpapan', '0542345678', 'balikpapan@cabang.com'),
	(11, 'Cabang Bogor', 'Jl. Pajajaran No.14, Bogor', '0251345678', 'bogor@cabang.com'),
	(12, 'Cabang Solo', 'Jl. Slamet Riyadi No.17, Solo', '0271345123', 'solo@cabang.com'),
	(13, 'Cabang Malang', 'Jl. Ijen No.19, Malang', '0341345678', 'malang@cabang.com'),
	(14, 'Cabang Pekanbaru', 'Jl. Tuanku Tambusai No.5, Pekanbaru', '0761234567', 'pekanbaru@cabang.com'),
	(15, 'Cabang Manado', 'Jl. Sam Ratulangi No.11, Manado', '0431234567', 'manado@cabang.com'),
	(16, 'Cabang Pontianak', 'Jl. Ahmad Yani No.13, Pontianak', '0561345678', 'pontianak@cabang.com'),
	(17, 'Cabang Jayapura', 'Jl. Abepura No.20, Jayapura', '0967234567', 'jayapura@cabang.com'),
	(18, 'Cabang Samarinda', 'Jl. Pahlawan No.4, Samarinda', '0541234567', 'samarinda@cabang.com'),
	(19, 'Cabang Padang', 'Jl. Adinegoro No.18, Padang', '0751234567', 'padang@cabang.com'),
	(20, 'Cabang Banjarmasin', 'Jl. A Yani No.23, Banjarmasin', '0511234567', 'banjarmasin@cabang.com');

-- Dumping structure for table penyewaan_futsal.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `id_customer` int NOT NULL AUTO_INCREMENT,
  `nama_customer` varchar(30) NOT NULL,
  `instansi` varchar(50) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kontak` varchar(15) NOT NULL,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.customer: ~20 rows (approximately)
INSERT INTO `customer` (`id_customer`, `nama_customer`, `instansi`, `alamat`, `kontak`) VALUES
	(1, 'Arjuna Putra', 'PT Maju Jaya', 'Jl. Melati No. 10, Jakarta', '081234567890'),
	(2, 'Dewi Ayu', 'CV Sentosa Abadi', 'Jl. Kenanga No. 20, Bandung', '081234567891'),
	(3, 'Budi Santoso', 'UD Makmur', 'Jl. Mawar No. 5, Surabaya', '081234567892'),
	(4, 'Siti Rahma', 'PT Cahaya Baru', 'Jl. Anggrek No. 30, Medan', '081234567893'),
	(5, 'Rizki Ramadhan', NULL, 'Jl. Tulip No. 15, Yogyakarta', '081234567894'),
	(6, 'Nanda Permana', 'CV Jaya Sentosa', 'Jl. Cempaka No. 25, Semarang', '081234567895'),
	(7, 'Eka Saputra', NULL, 'Jl. Melur No. 8, Malang', '081234567896'),
	(8, 'Rina Kurnia', 'PT Amanah Sejahtera', 'Jl. Teratai No. 12, Palembang', '081234567897'),
	(9, 'Agus Wijaya', 'UD Laris Manis', 'Jl. Dahlia No. 18, Pekanbaru', '081234567898'),
	(10, 'Nurul Hidayah', NULL, 'Jl. Seroja No. 22, Makassar', '081234567899'),
	(11, 'Yusuf Pratama', 'PT Prima Mandiri', 'Jl. Kamboja No. 14, Balikpapan', '081234567800'),
	(12, 'Farah Hanifa', NULL, 'Jl. Flamboyan No. 9, Padang', '081234567801'),
	(13, 'Adi Prasetyo', 'CV Unggul Bersama', 'Jl. Asoka No. 11, Pontianak', '081234567802'),
	(14, 'Maya Sari', 'PT Berkah Mulia', 'Jl. Melati No. 7, Samarinda', '081234567803'),
	(15, 'Dani Wijaya', NULL, 'Jl. Pala No. 19, Palu', '081234567804'),
	(16, 'Indah Cahyani', 'PT Sejahtera Group', 'Jl. Nangka No. 21, Jambi', '081234567805'),
	(17, 'Heri Kurniawan', NULL, 'Jl. Anggur No. 3, Kupang', '081234567806'),
	(18, 'Putri Amelia', 'CV Gemilang Jaya', 'Jl. Pisang No. 5, Mataram', '081234567807'),
	(19, 'Andi Saputra', NULL, 'Jl. Salak No. 13, Denpasar', '081234567808'),
	(20, 'Wulan Pertiwi', 'UD Sentosa Makmur', 'Jl. Durian No. 17, Manado', '081234567809');

-- Dumping structure for table penyewaan_futsal.detail_reservasi
CREATE TABLE IF NOT EXISTS `detail_reservasi` (
  `id_detail` int NOT NULL AUTO_INCREMENT,
  `tanggal_reservasi` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `sub_total` int NOT NULL DEFAULT '0',
  `status_penggunaan` enum('dijadwalkan','berlangsung','selesai','batal') NOT NULL,
  `id_lapangan` int NOT NULL,
  `id_pegawai` int NOT NULL,
  `id_customer` int NOT NULL,
  `id_transaksi` int NOT NULL,
  PRIMARY KEY (`id_detail`),
  KEY `id_lapangan` (`id_lapangan`),
  KEY `id_pegawai` (`id_pegawai`),
  KEY `id_customer` (`id_customer`),
  KEY `id_transaksi` (`id_transaksi`),
  CONSTRAINT `detail_reservasi_ibfk_1` FOREIGN KEY (`id_lapangan`) REFERENCES `lapangan` (`id_lapangan`),
  CONSTRAINT `detail_reservasi_ibfk_2` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id_pegawai`),
  CONSTRAINT `detail_reservasi_ibfk_3` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`),
  CONSTRAINT `detail_reservasi_ibfk_4` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.detail_reservasi: ~20 rows (approximately)
INSERT INTO `detail_reservasi` (`id_detail`, `tanggal_reservasi`, `jam_mulai`, `jam_selesai`, `sub_total`, `status_penggunaan`, `id_lapangan`, `id_pegawai`, `id_customer`, `id_transaksi`) VALUES
	(1, '2024-06-01', '10:00:00', '12:00:00', 500000, 'selesai', 1, 1, 1, 1),
	(2, '2024-06-02', '12:30:00', '14:30:00', 750000, 'selesai', 2, 1, 1, 2),
	(3, '2024-06-03', '14:00:00', '16:00:00', 600000, 'berlangsung', 3, 2, 2, 3),
	(4, '2024-06-05', '15:45:00', '17:45:00', 850000, 'selesai', 4, 2, 3, 4),
	(5, '2024-06-06', '10:30:00', '12:30:00', 700000, 'selesai', 5, 3, 4, 5),
	(6, '2024-06-07', '09:00:00', '11:00:00', 720000, 'selesai', 6, 3, 5, 6),
	(7, '2024-06-08', '11:15:00', '13:15:00', 750000, 'selesai', 7, 4, 6, 7),
	(8, '2024-06-09', '16:00:00', '18:00:00', 600000, 'selesai', 8, 4, 7, 8),
	(9, '2024-06-10', '13:30:00', '15:30:00', 850000, 'berlangsung', 9, 5, 8, 9),
	(10, '2024-06-11', '18:00:00', '20:00:00', 620000, 'selesai', 10, 5, 9, 10),
	(11, '2024-06-12', '12:00:00', '14:00:00', 900000, 'selesai', 1, 6, 10, 11),
	(12, '2024-06-13', '14:45:00', '16:45:00', 750000, 'selesai', 2, 6, 11, 12),
	(13, '2024-06-14', '09:30:00', '11:30:00', 800000, 'selesai', 3, 7, 12, 13),
	(14, '2024-06-15', '11:00:00', '13:00:00', 600000, 'selesai', 4, 7, 13, 14),
	(15, '2024-06-16', '13:15:00', '15:15:00', 720000, 'selesai', 5, 8, 14, 15),
	(16, '2024-06-17', '17:30:00', '19:30:00', 750000, 'selesai', 6, 8, 15, 16),
	(17, '2024-06-18', '10:45:00', '12:45:00', 870000, 'berlangsung', 7, 9, 16, 17),
	(18, '2024-06-19', '16:15:00', '18:15:00', 800000, 'selesai', 8, 9, 17, 18),
	(19, '2024-06-20', '12:45:00', '14:45:00', 900000, 'selesai', 9, 10, 18, 19),
	(20, '2024-06-21', '14:00:00', '16:00:00', 620000, 'selesai', 10, 10, 19, 20);

-- Dumping structure for table penyewaan_futsal.harga_lapangan
CREATE TABLE IF NOT EXISTS `harga_lapangan` (
  `id_harga` int NOT NULL AUTO_INCREMENT,
  `jenis_hari` enum('reguler','weekday','holiday','special day') NOT NULL DEFAULT 'reguler',
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `harga` int NOT NULL DEFAULT '0',
  `id_lapangan` int NOT NULL,
  PRIMARY KEY (`id_harga`),
  KEY `id_lapangan` (`id_lapangan`),
  CONSTRAINT `harga_lapangan_ibfk_1` FOREIGN KEY (`id_lapangan`) REFERENCES `lapangan` (`id_lapangan`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.harga_lapangan: ~32 rows (approximately)
INSERT INTO `harga_lapangan` (`id_harga`, `jenis_hari`, `jam_mulai`, `jam_selesai`, `harga`, `id_lapangan`) VALUES
	(1, 'weekday', '08:00:00', '10:00:00', 100000, 1),
	(2, 'holiday', '10:00:00', '12:00:00', 120000, 1),
	(3, 'special day', '18:00:00', '20:00:00', 150000, 2),
	(4, 'weekday', '12:00:00', '14:00:00', 90000, 3),
	(5, 'holiday', '16:00:00', '18:00:00', 110000, 3),
	(6, 'weekday', '08:00:00', '10:00:00', 95000, 4),
	(7, 'holiday', '14:00:00', '16:00:00', 130000, 5),
	(8, 'weekday', '10:00:00', '12:00:00', 85000, 6),
	(9, 'special day', '18:00:00', '20:00:00', 160000, 7),
	(10, 'weekday', '12:00:00', '14:00:00', 92000, 8),
	(11, 'holiday', '08:00:00', '10:00:00', 115000, 9),
	(12, 'weekday', '16:00:00', '18:00:00', 98000, 10),
	(13, 'holiday', '18:00:00', '20:00:00', 125000, 11),
	(14, 'special day', '12:00:00', '14:00:00', 140000, 12),
	(15, 'weekday', '08:00:00', '10:00:00', 90000, 13),
	(16, 'holiday', '14:00:00', '16:00:00', 135000, 14),
	(17, 'weekday', '18:00:00', '20:00:00', 95000, 15),
	(18, 'special day', '10:00:00', '12:00:00', 145000, 16),
	(19, 'holiday', '16:00:00', '18:00:00', 155000, 17),
	(20, 'weekday', '12:00:00', '14:00:00', 92000, 18),
	(21, 'special day', '18:00:00', '20:00:00', 150000, 19),
	(22, 'weekday', '08:00:00', '10:00:00', 93000, 20),
	(23, 'holiday', '10:00:00', '12:00:00', 120000, 21),
	(24, 'special day', '14:00:00', '16:00:00', 140000, 22),
	(25, 'weekday', '08:00:00', '10:00:00', 95000, 23),
	(26, 'holiday', '12:00:00', '14:00:00', 125000, 24),
	(27, 'special day', '16:00:00', '18:00:00', 150000, 25),
	(28, 'holiday', '10:00:00', '12:00:00', 135000, 26),
	(29, 'weekday', '08:00:00', '10:00:00', 100000, 27),
	(30, 'special day', '18:00:00', '20:00:00', 145000, 28),
	(31, 'holiday', '08:00:00', '10:00:00', 130000, 29),
	(32, 'weekday', '12:00:00', '14:00:00', 110000, 30);

-- Dumping structure for table penyewaan_futsal.jadwal_libur
CREATE TABLE IF NOT EXISTS `jadwal_libur` (
  `id_libur` int NOT NULL AUTO_INCREMENT,
  `tanggal_libur` date NOT NULL,
  `keterangan` text,
  `id_lapangan` int NOT NULL,
  PRIMARY KEY (`id_libur`),
  KEY `id_lapangan` (`id_lapangan`),
  CONSTRAINT `jadwal_libur_ibfk_1` FOREIGN KEY (`id_lapangan`) REFERENCES `lapangan` (`id_lapangan`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.jadwal_libur: ~31 rows (approximately)
INSERT INTO `jadwal_libur` (`id_libur`, `tanggal_libur`, `keterangan`, `id_lapangan`) VALUES
	(1, '2024-01-01', 'Tahun Baru', 1),
	(2, '2024-03-08', 'Perbaikan lantai', 2),
	(3, '2024-05-01', 'Hari Buruh', 3),
	(4, '2024-06-15', 'Pengecatan lapangan', 4),
	(5, '2024-07-17', 'Pemeliharaan jaring', 5),
	(6, '2024-08-17', 'Libur Nasional', 6),
	(7, '2024-09-01', 'Pembersihan area', 7),
	(8, '2024-09-15', 'Turnamen besar', 8),
	(9, '2024-10-01', 'Perbaikan pencahayaan', 9),
	(10, '2024-11-10', 'Hari Pahlawan', 10),
	(11, '2024-12-25', 'Libur Natal', 11),
	(12, '2024-01-15', 'Pemeliharaan rutin', 12),
	(13, '2024-02-20', 'Pengecatan ulang garis', 13),
	(14, '2024-04-25', 'Perbaikan pagar', 14),
	(15, '2024-06-01', 'Libur Pemeliharaan', 15),
	(16, '2024-07-01', 'Libur Nasional', 16),
	(17, '2024-08-10', 'Turnamen tahunan', 17),
	(18, '2024-09-20', 'Pembersihan rumput', 18),
	(19, '2024-10-15', 'Perbaikan atap', 19),
	(20, '2024-11-01', 'Hari Libur Umum', 20),
	(21, '2024-12-01', 'Pemeliharaan besar', 21),
	(22, '2024-05-15', 'Perbaikan pagar lapangan', 21),
	(23, '2024-07-10', 'Pengecatan baru', 22),
	(24, '2024-10-20', 'Libur Hari Besar', 23),
	(25, '2024-01-20', 'Turnamen komunitas', 24),
	(26, '2024-02-01', 'Libur cabang', 25),
	(27, '2024-03-10', 'Perbaikan fasilitas', 26),
	(28, '2024-04-05', 'Maintenance lapangan', 27),
	(29, '2024-06-20', 'Pengecekan rutin', 28),
	(30, '2024-07-25', 'Turnamen eksternal', 29),
	(31, '2024-08-05', 'Renovasi lapangan', 30);

-- Dumping structure for table penyewaan_futsal.jam_tutup
CREATE TABLE IF NOT EXISTS `jam_tutup` (
  `id_jam_tutup` int NOT NULL AUTO_INCREMENT,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `id_lapangan` int NOT NULL,
  PRIMARY KEY (`id_jam_tutup`),
  KEY `id_lapangan` (`id_lapangan`),
  CONSTRAINT `jam_tutup_ibfk_1` FOREIGN KEY (`id_lapangan`) REFERENCES `lapangan` (`id_lapangan`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.jam_tutup: ~35 rows (approximately)
INSERT INTO `jam_tutup` (`id_jam_tutup`, `jam_mulai`, `jam_selesai`, `id_lapangan`) VALUES
	(1, '06:00:00', '07:00:00', 1),
	(2, '12:00:00', '13:00:00', 1),
	(3, '18:00:00', '19:00:00', 2),
	(4, '07:00:00', '08:00:00', 3),
	(5, '14:00:00', '15:00:00', 3),
	(6, '20:00:00', '21:00:00', 4),
	(7, '10:00:00', '11:00:00', 4),
	(8, '16:00:00', '17:00:00', 5),
	(9, '08:00:00', '09:00:00', 5),
	(10, '12:00:00', '13:00:00', 6),
	(11, '17:00:00', '18:00:00', 7),
	(12, '09:00:00', '10:00:00', 7),
	(13, '13:00:00', '14:00:00', 8),
	(14, '11:00:00', '12:00:00', 8),
	(15, '19:00:00', '20:00:00', 9),
	(16, '06:00:00', '07:00:00', 9),
	(17, '18:00:00', '19:00:00', 10),
	(18, '15:00:00', '16:00:00', 10),
	(19, '20:00:00', '21:00:00', 11),
	(20, '07:00:00', '08:00:00', 11),
	(21, '09:00:00', '10:00:00', 12),
	(22, '16:00:00', '17:00:00', 13),
	(23, '12:00:00', '13:00:00', 13),
	(24, '19:00:00', '20:00:00', 14),
	(25, '08:00:00', '09:00:00', 15),
	(26, '07:00:00', '08:00:00', 15),
	(27, '13:00:00', '14:00:00', 16),
	(28, '14:00:00', '15:00:00', 17),
	(29, '10:00:00', '11:00:00', 18),
	(30, '11:00:00', '12:00:00', 18),
	(31, '06:00:00', '07:00:00', 19),
	(32, '17:00:00', '18:00:00', 20),
	(33, '18:00:00', '19:00:00', 21),
	(34, '14:00:00', '15:00:00', 21),
	(35, '20:00:00', '21:00:00', 22);

-- Dumping structure for table penyewaan_futsal.langganan
CREATE TABLE IF NOT EXISTS `langganan` (
  `id_langganan` int NOT NULL AUTO_INCREMENT,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status_langganan` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `harga_langganan` int NOT NULL DEFAULT '0',
  `id_customer` int NOT NULL,
  PRIMARY KEY (`id_langganan`),
  KEY `id_customer` (`id_customer`),
  CONSTRAINT `langganan_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.langganan: ~28 rows (approximately)
INSERT INTO `langganan` (`id_langganan`, `tanggal_mulai`, `tanggal_selesai`, `status_langganan`, `harga_langganan`, `id_customer`) VALUES
	(1, '2024-01-01', '2024-03-01', 'nonaktif', 500000, 1),
	(2, '2024-03-02', '2024-06-02', 'aktif', 750000, 1),
	(3, '2024-01-10', '2024-04-10', 'nonaktif', 600000, 2),
	(4, '2024-04-11', '2024-07-11', 'aktif', 800000, 2),
	(5, '2024-02-01', '2024-05-01', 'nonaktif', 700000, 3),
	(6, '2024-01-15', '2024-03-15', 'aktif', 650000, 4),
	(7, '2024-01-20', '2024-04-20', 'nonaktif', 720000, 5),
	(8, '2024-04-21', '2024-07-21', 'aktif', 900000, 5),
	(9, '2024-02-01', '2024-05-01', 'aktif', 780000, 6),
	(10, '2024-03-01', '2024-06-01', 'nonaktif', 600000, 7),
	(11, '2024-01-05', '2024-04-05', 'aktif', 850000, 8),
	(12, '2024-02-10', '2024-05-10', 'nonaktif', 620000, 9),
	(13, '2024-05-11', '2024-08-11', 'aktif', 870000, 9),
	(14, '2024-01-12', '2024-04-12', 'nonaktif', 500000, 10),
	(15, '2024-01-25', '2024-03-25', 'aktif', 750000, 11),
	(16, '2024-02-15', '2024-05-15', 'nonaktif', 720000, 12),
	(17, '2024-03-01', '2024-06-01', 'aktif', 800000, 13),
	(18, '2024-01-20', '2024-04-20', 'nonaktif', 600000, 14),
	(19, '2024-01-15', '2024-03-15', 'aktif', 780000, 15),
	(20, '2024-02-10', '2024-05-10', 'aktif', 880000, 16),
	(21, '2024-01-01', '2024-04-01', 'nonaktif', 600000, 17),
	(22, '2024-04-02', '2024-07-02', 'aktif', 900000, 17),
	(23, '2024-03-01', '2024-06-01', 'aktif', 800000, 18),
	(24, '2024-02-05', '2024-05-05', 'nonaktif', 620000, 19),
	(25, '2024-05-06', '2024-08-06', 'aktif', 870000, 19),
	(26, '2024-01-10', '2024-04-10', 'nonaktif', 500000, 20),
	(27, '2024-04-11', '2024-07-11', 'aktif', 850000, 20),
	(28, '2024-07-12', '2024-10-12', 'nonaktif', 900000, 20);

-- Dumping structure for table penyewaan_futsal.lapangan
CREATE TABLE IF NOT EXISTS `lapangan` (
  `id_lapangan` int NOT NULL AUTO_INCREMENT,
  `nama_lapangan` varchar(30) NOT NULL,
  `deskripsi_lapangan` text NOT NULL,
  `status_lapangan` enum('tersedia','maintenance','tutup') NOT NULL DEFAULT 'tersedia',
  `id_cabang` int NOT NULL,
  PRIMARY KEY (`id_lapangan`),
  KEY `id_cabang` (`id_cabang`),
  CONSTRAINT `lapangan_ibfk_1` FOREIGN KEY (`id_cabang`) REFERENCES `cabang` (`id_cabang`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.lapangan: ~35 rows (approximately)
INSERT INTO `lapangan` (`id_lapangan`, `nama_lapangan`, `deskripsi_lapangan`, `status_lapangan`, `id_cabang`) VALUES
	(1, 'Alpha Court', 'Lapangan futsal indoor dengan lantai vinyl berkualitas tinggi', 'tersedia', 1),
	(2, 'Beta Field', 'Lapangan futsal outdoor dengan rumput sintetis kondisi baik', 'maintenance', 2),
	(3, 'Gamma Arena', 'Lapangan futsal indoor dengan penerangan LED optimal', 'tersedia', 3),
	(4, 'Delta Ground', 'Lapangan futsal outdoor dalam tahap pengecatan ulang', 'maintenance', 4),
	(5, 'Epsilon Court', 'Lapangan futsal indoor dengan lantai berstandar FIFA', 'tersedia', 5),
	(6, 'Zeta Pitch', 'Lapangan futsal outdoor dengan permukaan sintetis', 'tersedia', 1),
	(7, 'Eta Zone', 'Lapangan futsal indoor berpendingin udara', 'tutup', 2),
	(8, 'Theta Field', 'Lapangan futsal outdoor dalam perbaikan pagar pembatas', 'maintenance', 3),
	(9, 'Iota Ground', 'Lapangan futsal indoor kondisi siap pakai', 'tersedia', 4),
	(10, 'Kappa Arena', 'Lapangan futsal outdoor dengan garis lapangan baru', 'tersedia', 5),
	(11, 'Lambda Zone', 'Lapangan futsal indoor dengan ventilasi udara alami', 'tutup', 6),
	(12, 'Mu Pitch', 'Lapangan futsal outdoor kondisi lapangan berlubang', 'maintenance', 7),
	(13, 'Nu Court', 'Lapangan futsal indoor dengan tribun penonton kecil', 'tersedia', 8),
	(14, 'Xi Field', 'Lapangan futsal outdoor dalam proses renovasi atap', 'maintenance', 9),
	(15, 'Omicron Arena', 'Lapangan futsal indoor dengan pencahayaan LED minimalis', 'tersedia', 10),
	(16, 'Pi Zone', 'Lapangan futsal outdoor dengan pagar pembatas rusak', 'maintenance', 6),
	(17, 'Rho Pitch', 'Lapangan futsal indoor dengan kondisi lantai licin', 'tersedia', 7),
	(18, 'Sigma Court', 'Lapangan futsal outdoor sedang dalam pengecatan', 'maintenance', 8),
	(19, 'Tau Ground', 'Lapangan futsal indoor kondisi prima untuk turnamen', 'tersedia', 9),
	(20, 'Upsilon Field', 'Lapangan futsal outdoor dengan garis lapangan usang', 'maintenance', 10),
	(21, 'Phi Arena', 'Lapangan futsal indoor dengan tribun penonton kapasitas besar', 'tersedia', 1),
	(22, 'Chi Zone', 'Lapangan futsal outdoor dalam tahap renovasi jaring gawang', 'maintenance', 2),
	(23, 'Psi Ground', 'Lapangan futsal indoor dengan sistem ventilasi otomatis', 'tersedia', 3),
	(24, 'Omega Field', 'Lapangan futsal outdoor beralaskan rumput sintetis tua', 'tersedia', 4),
	(25, 'Vega Court', 'Lapangan futsal indoor dengan kondisi cat lapangan baru', 'tersedia', 5),
	(26, 'Nova Pitch', 'Lapangan futsal outdoor sedang dalam perbaikan garis lapangan', 'maintenance', 6),
	(27, 'Quasar Arena', 'Lapangan futsal indoor dalam kondisi sempurna untuk turnamen besar', 'tersedia', 7),
	(28, 'Nebula Zone', 'Lapangan futsal outdoor dengan pagar pengaman rendah', 'maintenance', 8),
	(29, 'Pulsar Court', 'Lapangan futsal indoor dengan kondisi pendingin rusak', 'tutup', 9),
	(30, 'Aurora Field', 'Lapangan futsal outdoor dalam perbaikan tiang gawang', 'tersedia', 10),
	(31, 'Horizon Arena', 'Lapangan futsal indoor dengan lantai karet berkualitas premium', 'tersedia', 2),
	(32, 'Zenith Zone', 'Lapangan futsal outdoor dengan garis lapangan baru', 'maintenance', 3),
	(33, 'Atlas Court', 'Lapangan futsal indoor dengan sistem pencahayaan maksimal', 'tersedia', 4),
	(34, 'Cosmos Pitch', 'Lapangan futsal outdoor dalam perawatan rumput sintetis', 'maintenance', 5),
	(35, 'Galaxy Ground', 'Lapangan futsal indoor siap pakai untuk latihan harian', 'tersedia', 6);

-- Dumping structure for table penyewaan_futsal.pegawai
CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kontak` varchar(15) NOT NULL,
  `id_cabang` int NOT NULL,
  PRIMARY KEY (`id_pegawai`),
  KEY `id_cabang` (`id_cabang`),
  CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`id_cabang`) REFERENCES `cabang` (`id_cabang`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.pegawai: ~20 rows (approximately)
INSERT INTO `pegawai` (`id_pegawai`, `username`, `password`, `nama_lengkap`, `alamat`, `kontak`, `id_cabang`) VALUES
	(1, 'user_jkt1', 'pass123', 'Andi Prasetyo', 'Jl. Melati No.1', '0811111111', 1),
	(2, 'user_bdg1', 'pass456', 'Siti Hidayah', 'Jl. Mawar No.2', '0812222222', 2),
	(3, 'user_sby1', 'pass789', 'Budi Santoso', 'Jl. Anggrek No.3', '0813333333', 3),
	(4, 'user_mdn1', 'pass321', 'Indah Lestari', 'Jl. Dahlia No.4', '0814444444', 4),
	(5, 'user_bli1', 'pass654', 'Ketut Wijaya', 'Jl. Teratai No.5', '0815555555', 5),
	(6, 'user_smg1', 'pass987', 'Ahmad Rasyid', 'Jl. Flamboyan No.6', '0816666666', 6),
	(7, 'user_mks1', 'pass147', 'Sri Wahyuni', 'Jl. Kemuning No.7', '0817777777', 7),
	(8, 'user_plb1', 'pass258', 'Reza Ramadhan', 'Jl. Kenanga No.8', '0818888888', 8),
	(9, 'user_yog1', 'pass369', 'Dewi Arum', 'Jl. Tulip No.9', '0819999999', 9),
	(10, 'user_bpn1', 'pass741', 'Riko Wijaya', 'Jl. Bougenville No.10', '0821111111', 10),
	(11, 'user_bgr1', 'pass852', 'Nina Saputra', 'Jl. Melur No.11', '0822222222', 11),
	(12, 'user_slo1', 'pass963', 'Fajar Nugraha', 'Jl. Sakura No.12', '0823333333', 12),
	(13, 'user_mlg1', 'pass159', 'Aulia Febriani', 'Jl. Kamboja No.13', '0824444444', 13),
	(14, 'user_pku1', 'pass753', 'Yudha Pratama', 'Jl. Seruni No.14', '0825555555', 14),
	(15, 'user_mdo1', 'pass951', 'Maya Kusuma', 'Jl. Puspa No.15', '0826666666', 15),
	(16, 'user_ptk1', 'pass357', 'Rani Setiawan', 'Jl. Amarilis No.16', '0827777777', 16),
	(17, 'user_jpr1', 'pass654', 'Tommy Sukardi', 'Jl. Sedap Malam No.17', '0828888888', 17),
	(18, 'user_smr1', 'pass753', 'Laila Wati', 'Jl. Seroja No.18', '0829999999', 18),
	(19, 'user_pdg1', 'pass852', 'Robby Taufik', 'Jl. Kenari No.19', '0831111111', 19),
	(20, 'user_bjm1', 'pass951', 'Yusuf Maulana', 'Jl. Melati No.20', '0832222222', 20);

-- Dumping structure for table penyewaan_futsal.transaksi
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` int NOT NULL AUTO_INCREMENT,
  `tanggal_transaksi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_pembayaran` int NOT NULL DEFAULT '0',
  `total_dibayar` int NOT NULL DEFAULT '0',
  `status_transaksi` enum('draft','belum dibayar','lunas','batal') NOT NULL DEFAULT 'draft',
  `metode_pembayaran` enum('none','tunai','transfer','ewallet') NOT NULL DEFAULT 'none',
  `id_pegawai` int NOT NULL,
  `id_customer` int NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_pegawai` (`id_pegawai`),
  KEY `id_customer` (`id_customer`),
  CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id_pegawai`),
  CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table penyewaan_futsal.transaksi: ~20 rows (approximately)
INSERT INTO `transaksi` (`id_transaksi`, `tanggal_transaksi`, `total_pembayaran`, `total_dibayar`, `status_transaksi`, `metode_pembayaran`, `id_pegawai`, `id_customer`) VALUES
	(1, '2024-06-01 10:00:00', 500000, 500000, 'lunas', 'tunai', 1, 1),
	(2, '2024-06-02 12:30:00', 750000, 750000, 'lunas', 'transfer', 1, 1),
	(3, '2024-06-03 14:00:00', 600000, 500000, 'belum dibayar', 'tunai', 2, 2),
	(4, '2024-06-05 15:45:00', 850000, 850000, 'lunas', 'ewallet', 2, 3),
	(5, '2024-06-06 10:30:00', 700000, 700000, 'lunas', 'transfer', 3, 4),
	(6, '2024-06-07 09:00:00', 720000, 720000, 'lunas', 'tunai', 3, 5),
	(7, '2024-06-08 11:15:00', 750000, 750000, 'lunas', 'ewallet', 4, 6),
	(8, '2024-06-09 16:00:00', 600000, 600000, 'lunas', 'tunai', 4, 7),
	(9, '2024-06-10 13:30:00', 850000, 850000, 'lunas', 'transfer', 5, 8),
	(10, '2024-06-11 18:00:00', 620000, 500000, 'belum dibayar', 'tunai', 5, 9),
	(11, '2024-06-12 12:00:00', 900000, 900000, 'lunas', 'transfer', 6, 10),
	(12, '2024-06-13 14:45:00', 750000, 750000, 'lunas', 'tunai', 6, 11),
	(13, '2024-06-14 09:30:00', 800000, 800000, 'lunas', 'ewallet', 7, 12),
	(14, '2024-06-15 11:00:00', 600000, 600000, 'lunas', 'tunai', 7, 13),
	(15, '2024-06-16 13:15:00', 720000, 720000, 'lunas', 'transfer', 8, 14),
	(16, '2024-06-17 17:30:00', 750000, 750000, 'lunas', 'tunai', 8, 15),
	(17, '2024-06-18 10:45:00', 870000, 870000, 'lunas', 'ewallet', 9, 16),
	(18, '2024-06-19 16:15:00', 800000, 800000, 'lunas', 'transfer', 9, 17),
	(19, '2024-06-20 12:45:00', 900000, 900000, 'lunas', 'tunai', 10, 18),
	(20, '2024-06-21 14:00:00', 620000, 600000, 'belum dibayar', 'transfer', 10, 19);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
